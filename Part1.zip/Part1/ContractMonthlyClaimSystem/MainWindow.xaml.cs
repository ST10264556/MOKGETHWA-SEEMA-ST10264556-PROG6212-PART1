﻿using System.Windows;


namespace ContractMonthlyClaimSystem
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }


        private void Dashboard_Click(object sender, RoutedEventArgs e)
        {
            new Views.Dashboard().Show();
        }


        private void NewClaim_Click(object sender, RoutedEventArgs e)
        {
            new Views.NewClaim().Show();
        }


        private void ClaimDetail_Click(object sender, RoutedEventArgs e)
        {
            new Views.ClaimDetail().Show();
        }


        private void ApprovalPanel_Click(object sender, RoutedEventArgs e)
        {
            new Views.ApprovalPanel().Show();
        }
    }
}